package com.upexchange.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.view.WindowManager;
public class MainActivity extends Activity { @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); WebView w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setAllowFileAccess(false); w.getSettings().setAllowContentAccess(false); setContentView(w); w.loadUrl("file:///android_asset/index.html");} }
