# UP EXCHANGE Android demo
Offline prototype, no real funds or authentication. Debug APK for testing only.

## Build online
1. Extract this ZIP. Create a GitHub repository (main branch).
2. Upload the entire extracted project contents to the repository root, including the hidden .github/workflows/android.yml file. Preserve directories. GitHub web upload can omit hidden directories; create the workflow using Add file > Create new file if needed.
3. Open Actions > Build UP EXCHANGE APK > Run workflow. A push to main also triggers the build.
4. After a successful run, download the UP-EXCHANGE-debug-APK artifact and extract app-debug.apk.
5. Install on Android, allowing installation from your chosen source only if you trust the build. Turn that permission off afterward.

Alternatively use Android Studio with JDK 17 and SDK 35, or Gradle 8.9 with those dependencies: gradle assembleDebug.

Build workflow has not been executed in this environment. GitHub-hosted runner use is subject to account quotas. This is not a release-signed APK, and it is not ready for live trading or Play distribution. Login is a guest preview. Balances are simulated and reset on reload.
